import { QuizHistory } from "@/features/quiz-history/screens/quiz-history"

export default function QuizHistoryPage() {
  return <QuizHistory />
}
